import React from 'react'

export const FeedbackHeader = () => {
  return (
    <div>
        {/* header  */}
        <div className='header'>
                <h2 style={{color: '#fff' }}>Feedback App </h2>
            </div>
            {/*  / header */}
    </div>
  )
}
