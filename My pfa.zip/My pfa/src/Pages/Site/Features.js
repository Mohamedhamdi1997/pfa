import React from 'react'
import { NavLink } from "react-router-dom";

const Features = () => {
  return (
    <div>
        <div id='features' className='text-center'>
      <div className='container'>
        <div className='col-md-10 col-md-offset-1 section-title'>
          
          <h2>Découvrez MADRASTI</h2>
        </div>
       <div className="row">
           <div className="col circle un "><p>40 Ecoles</p></div>
           <div className="col circle deux"><p>250 Enseignants</p></div>
           <div className="col circle trois"><p>3000 Eléves</p></div>
           <div className="col circle quatre"><p>6000 Parents</p></div>
       </div>
        
        <div className="client">✅ 97% des clients MADRASTI considèrent cet investissement réussi</div>
        <div> <NavLink to="/user/register"><button className=" btn-ins ">S'inscrie</button></NavLink></div>
      </div>
    </div>
    </div>
  )
}

export default Features
