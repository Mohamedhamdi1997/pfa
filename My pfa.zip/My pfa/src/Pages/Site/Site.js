import React from 'react'
import { useParams } from 'react-router-dom'
import './site.css'
import Bar from './Bar'
import Header from './Header'
import Features from './Features'
import About from './About'
import Avis from './Avis'
import Footer from './Footer'
const Site = () => {
  return (
    <div>
      <Bar/>
      <Header/>
      <Features/>
      <About/>
      <Avis/>
      <Footer/>
    </div>
  )
}

export default Site
