import React from 'react'

const Avis = () => {
  return (
    <div>
      <div id='testimonials'>
      <div className='container'>
        <div className='col-md-10 col-md-offset-1 section-title text-center'>
          <h2>Notre communauté Facebook</h2>
        </div>
        <div className='row'>
         <div className="col ">
               <div className="col-4"><img src="../../testimonials/01.jpg" alt="bb"/></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div>
          </div>
           <div className="col">
             <div className="col-4"><img src="../../testimonials/02.jpg" alt="nn"/></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div>  
          </div>
           <div className="col">
              <div className="col-4 rounded"><img src="../../testimonials/03.jpg" alt="nn" /></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div>  
          </div></div>
          <div className="row">
          <div className="col">
            <div className="col-4"><img src="../../testimonials/04.jpg" alt="nn"/></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div></div>
               
           <div className="col">
                <div className="col-4"><img src="../../testimonials/05.jpg" alt="nn"/></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div></div>
           <div className="col">
                <div className="col-4"><img src="../../testimonials/06.jpg" alt="nn"/></div>
                <div className="col-8">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.""
         - John Doe</div></div>
        </div>
       
      </div>
    </div>
    </div>
  )
}

export default Avis
