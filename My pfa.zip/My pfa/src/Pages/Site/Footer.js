import React from 'react'

const Footer = () => {
  return (
    <div>
        <div id='footer'>
          <div className='container text-center'>
            <p>
              Copyright &copy; 2023 MADRASTI Inc. All Rights Reserved
            </p>
      
          </div>
        </div>
    </div>
  )
}

export default Footer
